package com.example.invoicemanagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InvoicemanagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(InvoicemanagementApplication.class, args);
	}

}
