package com.example.invoicemanagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InvoicemanagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
